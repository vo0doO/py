export var VIEWS;
(function (VIEWS) {
    VIEWS["HOME"] = "/";
    VIEWS["PORTFOLIO"] = "/portfolio";
})(VIEWS || (VIEWS = {}));
//# sourceMappingURL=constants.js.map