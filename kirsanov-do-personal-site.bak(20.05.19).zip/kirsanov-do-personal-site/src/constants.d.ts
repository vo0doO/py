export declare enum VIEWS {
    HOME = "/",
    PORTFOLIO = "/portfolio"
}
