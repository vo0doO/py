export declare const homeView: import("lit-element").TemplateResult;
