export enum VIEWS {
  HOME = "/",
  PORTFOLIO = "/portfolio",
}
